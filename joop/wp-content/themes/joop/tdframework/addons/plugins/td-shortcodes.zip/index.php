<?php
/*
 * Silence is golden.
 */
?>