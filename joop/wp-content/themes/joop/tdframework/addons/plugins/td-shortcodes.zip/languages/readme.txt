
place your tdshortcodes-xx_XX.mo and tdshortcodes-xx_XX.po in wp-content/languages/plugins/


Please visit the following links to learn more about translating WordPress themes:
http://codex.wordpress.org/Translating_WordPress
http://codex.wordpress.org/Function_Reference/load_theme_textdomain
