<?php

/* Silence is golden.

?>